*The "myFile.txt" that is in here is just a placeholder to show how the program would work assuming you haven't set up the bluetooth ESP32 (which would send the file to this program). 

*Youtube Link to Video: https://www.youtube.com/watch?v=2RHqWr6QWHc
*Link to Website: https://pushover.net/